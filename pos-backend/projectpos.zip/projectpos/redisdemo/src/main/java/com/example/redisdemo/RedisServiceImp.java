package com.example.redisdemo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RedisServiceImp implements RedisService {
    @Autowired
    @Qualifier("newredisTemplate")
    private RedisTemplate redisTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public ProductDTO objectDeserializer(String str) throws JsonProcessingException {
        return objectMapper.readValue(str, ProductDTO.class);
    }

    @Override
    public String objectSerializer(ProductDTO productDTO) throws JsonProcessingException{

        return objectMapper.writeValueAsString(productDTO);

    }

    @Override
    public void insert(List<ProductDTO> productDTOList) throws JsonProcessingException {
        System.out.println("call");
        for(int i=0;i<productDTOList.size();i++) {
            System.out.println(productDTOList.get(i));
            redisTemplate.opsForList().leftPush("list", objectSerializer(productDTOList.get(i)));
        }

    }

    @Override
    public List<ProductDTO> getAll() throws JsonProcessingException {
        List<ProductDTO>list=new ArrayList<>();
        List<String>li=redisTemplate.opsForList().range("list",0,4);
        for(int i=0;i<5;i++){
            list.add(objectDeserializer(li.get(i)));
        }
        return list;
    }

}
