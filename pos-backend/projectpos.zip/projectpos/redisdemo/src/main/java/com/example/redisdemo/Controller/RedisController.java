package com.example.redisdemo.Controller;


import com.example.redisdemo.Constant;
import com.example.redisdemo.ProductDTO;
import com.example.redisdemo.RedisService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.yaml.snakeyaml.serializer.SerializerException;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping(Constant.REDIS)
public class RedisController {

    @Autowired
    RedisService redisService;

    @GetMapping(Constant.GET_ALL)
    public List<ProductDTO> getAll() throws JsonProcessingException {
        return redisService.getAll();
    }

    @PostMapping(Constant.INSERT)
    public void insert(@RequestBody  List<ProductDTO> productDTO) throws JsonProcessingException {
        redisService.insert(productDTO);
    }

}
