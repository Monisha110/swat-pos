package com.example.redisdemo;


import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;

public interface RedisService {

    ProductDTO objectDeserializer(String str) throws JsonProcessingException;

    String objectSerializer(ProductDTO productDTO) throws JsonProcessingException;


    void insert(List<ProductDTO> productDTO) throws JsonProcessingException;

    List<ProductDTO> getAll() throws JsonProcessingException;

}
