package com.example.redisdemo;

public class RedisException extends Exception {
    public RedisException(String str){
        super(str);
    }
}
