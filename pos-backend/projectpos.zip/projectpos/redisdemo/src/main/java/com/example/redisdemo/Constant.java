package com.example.redisdemo;

public class Constant {
    public static final String LOCALHOST="localhost";
    public static final int PORT_NUMBER=6379;
    public static final String  REDIS="/redis";
    public static final String GET_ALL="/getAll";
    public static final String INSERT="/insert";
}
