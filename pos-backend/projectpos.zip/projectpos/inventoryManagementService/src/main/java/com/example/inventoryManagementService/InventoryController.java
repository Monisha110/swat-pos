package com.example.inventoryManagementService;

import com.example.inventoryManagementService.Authentication.Constants;
import com.example.inventoryManagementService.customExceptions.InvalidDataProvidedException;
import com.example.inventoryManagementService.customExceptions.NotEnoughQuanityException;
import com.example.inventoryManagementService.customExceptions.ProductNotFoundException;
import com.example.inventoryManagementService.models.Product;
import com.example.inventoryManagementService.models.ProductDTO;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import sun.security.util.SecurityConstants;

import java.util.ArrayList;
import java.util.List;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping(Constants.INVENTORY_BASE_URL)
public class InventoryController {

    @Autowired
    InventoryService inventoryService;

    @Autowired
    ModelMapper modelMapper;


    @GetMapping(Constants.INVENTORY_GET_BY_ID)
    public ProductDTO getProductById(@PathVariable int id) {
        try {
            return modelMapper.map(inventoryService.getById(id),ProductDTO.class);

        } catch (ProductNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage());
        }
    }

    @GetMapping(Constants.INVENTORY_GET_BY_Name)
    public List<ProductDTO> getProductByName(@PathVariable("name") String name) {
        try {
            List<Product>productList=inventoryService.getByName(name);
            return modelMapper.map(productList,new TypeToken<List<ProductDTO>>(){}.getType());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    @GetMapping(Constants.INVENTORY_SEARCH)
    public List<ProductDTO> searchProductByName(@RequestParam String name) {
        try {
            List<Product>productList=inventoryService.searchByName(name);
            return modelMapper.map(productList,new TypeToken<List<ProductDTO>>(){}.getType());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @GetMapping(Constants.INVENTORY_GET_ALL)
    public Page<Product> getAll(@RequestParam int page, @RequestParam int size) {
        try {
            return inventoryService.getAll(page,size);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping(Constants.INVENTORY_ADD)
    public ProductDTO postProduct(@RequestBody ProductDTO product) {

        try {
            return inventoryService.postProduct(product);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }


    @PostMapping(Constants.INVENTORY_ADD_ALL)
    public Iterable<Product> postAllProduct(@RequestBody List<ProductDTO> productsDTO) {
        try {
            return inventoryService.postProduct(productsDTO);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping(Constants.INVENTORY_CHECK_STOCK)
    public boolean checkProductStock(@RequestBody ProductDTO product){
        try {
            return inventoryService.checkStocks(product);
        }catch (ProductNotFoundException | NotEnoughQuanityException | InvalidDataProvidedException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping(Constants.INVENTORY_CHECK_STOCK_ALL)
    public boolean checkProductStocks(@RequestBody List<ProductDTO> productDTOS){
        try {
            System.out.println (productDTOS );
            return inventoryService.checkStocks(productDTOS);
        }catch (ProductNotFoundException | NotEnoughQuanityException | InvalidDataProvidedException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping(Constants.INVENTORY_INCREMENT)
    public boolean incrementProductQuantity(@RequestBody ProductDTO product){
        try {
            return inventoryService.incrementQuantity(product);
        }catch (ProductNotFoundException | InvalidDataProvidedException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping(Constants.INVENTORY_INCREMENT_ALL)
    public boolean incrementProductsQuantity(@RequestBody List<ProductDTO> products){
        try {
            return inventoryService.incrementQuantity(products);
        }catch (ProductNotFoundException | InvalidDataProvidedException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping(Constants.INVENTORY_REDUCE)
    public boolean reduceQuantityProduct(@RequestBody ProductDTO product){
        try {
            return inventoryService.reduceQuantity(product);
        }catch (ProductNotFoundException | InvalidDataProvidedException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping(Constants.INVENTORY_REDUCE_ALL)
    public boolean reduceQuantityProducts(@RequestBody List<ProductDTO> products){
        try {
            return inventoryService.reduceQuantity(products);
        }catch (ProductNotFoundException | InvalidDataProvidedException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PutMapping(Constants.INVENTORY_UPDATE)
    public Product putProduct(@RequestBody ProductDTO product) {

        try {
            System.out.println("update is executed");
            return inventoryService.putProduct(product);
        }catch (ProductNotFoundException | InvalidDataProvidedException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            e.printStackTrace();
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @DeleteMapping(Constants.INVENTORY_DELETE)
    public Product deleteProduct(@PathVariable int productId) {
        try {
            return inventoryService.deleteProduct(productId);
        }catch (ProductNotFoundException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @GetMapping(Constants.PRODUCT_COUNT)
    public long productCount()
    {
        //System.out.println("product count");
        return inventoryService.productCount ();
    }

    @GetMapping(Constants.MINIMUM_STOCK_COUNT)
    public long minimumStockCount()
    {
        return inventoryService.minimumStockCount ();
    }
    @GetMapping(Constants.MINIMUM_STOCK_PRODUCT)
    public List<ProductDTO> minimumStockProduct()
    {
        return inventoryService.minimumStock ();
    }

    @GetMapping(Constants.OUT_OF_STOCK_COUNT)
    public long outOfStockCount()
    {
        return inventoryService.outOfStockCount ( );
    }
    @GetMapping(Constants.OUT_OF_STOCK_PRODUCT)
    public List<ProductDTO> outOfStockProduct()
    {
        return inventoryService.outOfStockProduct ();
    }
}
