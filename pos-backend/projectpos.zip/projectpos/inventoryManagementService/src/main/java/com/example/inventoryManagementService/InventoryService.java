package com.example.inventoryManagementService;

import com.example.inventoryManagementService.customExceptions.*;
import com.example.inventoryManagementService.models.Product;
import com.example.inventoryManagementService.models.ProductDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.data.domain.Page;

import java.util.List;

public interface InventoryService {

    Product getById(int productId) throws ProductNotFoundException;

    List<Product> getByName(String name);

    List<Product> searchByName(String query);

    Page<Product> getAll(int page,int size);


    ProductDTO postProduct(ProductDTO productDTO)throws InvalidDataProvidedException;

    Iterable<Product> postProduct(List<ProductDTO> productDTOS);

    List<ProductDTO> incrementQuantityViaKafka(String data) throws JsonProcessingException, ProductNotFoundException, InvalidDataProvidedException;

    boolean checkStocks(ProductDTO productDTO) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException;
    boolean checkStocks(List<ProductDTO> productDTOS) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException;

    boolean incrementQuantity(ProductDTO product) throws ProductNotFoundException, InvalidDataProvidedException;
    boolean incrementQuantity(List<ProductDTO> product) throws ProductNotFoundException, InvalidDataProvidedException;

    boolean reduceQuantity(ProductDTO product) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException;
    boolean reduceQuantity(List<ProductDTO> product) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException;

    Product putProduct(ProductDTO product) throws  InvalidDataProvidedException, ProductNotFoundException;

    Product deleteProduct(int productId) throws ProductNotFoundException;

    long productCount();

    long minimumStockCount();

    List<ProductDTO> minimumStock();

    long outOfStockCount();

    List<ProductDTO> outOfStockProduct();

}
