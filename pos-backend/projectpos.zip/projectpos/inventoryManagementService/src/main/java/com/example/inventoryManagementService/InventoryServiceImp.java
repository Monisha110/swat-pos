package com.example.inventoryManagementService;

import com.example.inventoryManagementService.customExceptions.*;
import com.example.inventoryManagementService.models.Product;
import com.example.inventoryManagementService.models.ProductDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
public class InventoryServiceImp implements InventoryService {

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    InventoryRepository inventoryRepository;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    Logger logger;

    @Value ("${spring.minimumStock}")
    private int minimumStockRange;

    @Value ("${spring.outOfStock}")
    private int outOfStockRange;
    @Override
    public Product getById(int productId) throws ProductNotFoundException {

        Optional<Product> product = inventoryRepository.findById(productId);

        if (!product.isPresent()) {
            throw new ProductNotFoundException("Product Not Found");
        }

        return product.get();

    }

    @Override
    public List<Product> getByName(String name) {
        return inventoryRepository.findAllByName(name);
    }

    @Override
    public List<Product> searchByName(String query) {
        if(query.length()==0){
            System.out.println("query"+inventoryRepository.findAll());
            return (List<Product>) inventoryRepository.findAll();
        }
        return inventoryRepository.findAllByNameContainingIgnoreCase(query,Sort.by(Sort.Direction.ASC,"name").and(Sort.by(Sort.Direction.DESC,"quantity")));
    }

    @Override
    public Page<Product> getAll(int page, int size) {
        PageRequest pr = PageRequest.of(page,size,Sort.by("quantity").descending());
        System.out.println(inventoryRepository.findAll(pr));
        return inventoryRepository.findAll(pr);
    }

    @Override
    public ProductDTO postProduct(ProductDTO productDTO)throws InvalidDataProvidedException {
        Product product=modelMapper.map(productDTO,Product.class);
        checkValidQuantityProvided (productDTO);
        inventoryRepository.save (product);
        return modelMapper.map (product, ProductDTO.class);
    }

    @Override
    public Iterable<Product> postProduct(List<ProductDTO> productDTOS) {
        List<Product>products=new ArrayList<>();
        for(ProductDTO productDTO:productDTOS){
            products.add(modelMapper.map(productDTO,Product.class));
        }
        return inventoryRepository.saveAll(products);
    }

    @Override
    public List<ProductDTO> incrementQuantityViaKafka(String message)
            throws JsonProcessingException, ProductNotFoundException, InvalidDataProvidedException {

        TypeReference<List<ProductDTO>> ref = new TypeReference<List<ProductDTO>>() {
        };

        List<ProductDTO> orderedProducts = objectMapper.readValue(message, ref);
        incrementQuantity(orderedProducts);
        return orderedProducts;
    }

    @Override
    public boolean checkStocks(ProductDTO orderedProduct) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException {


        checkValidQuantityProvided(orderedProduct);

        Optional<Product> result = inventoryRepository.findById(orderedProduct.getId());

        if (!result.isPresent()) {
            throw new ProductNotFoundException("Invalid Product Id with " + orderedProduct.getId());
        }

        Product originalProduct = result.get();

        if (originalProduct.getQuantity() < orderedProduct.getQuantity()) {
            throw new NotEnoughQuanityException("Not enough Quantity");
        }

        return true;
    }

    @Override
    public boolean checkStocks(List<ProductDTO> productDTOS) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException {

        for(ProductDTO product :productDTOS){
            checkStocks(product);
        }
        return true;
    }

    @Override
    public boolean incrementQuantity(ProductDTO product) throws ProductNotFoundException, InvalidDataProvidedException {

        checkValidQuantityProvided(product);
        updateQuantity(product,true);
        return true;
    }

    @Override
    public boolean incrementQuantity(List<ProductDTO> products) throws ProductNotFoundException, InvalidDataProvidedException {

        checkValidQuantityProvided(products);

        for(ProductDTO product:products){
            updateQuantity(product,true);
        }

        return true;
    }

    @Override
    public boolean reduceQuantity(ProductDTO product) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException {

        checkValidQuantityProvided(product);
        checkStocks(product);

        updateQuantity(product,false);

        return true;
    }

    @Override
    public boolean reduceQuantity(List<ProductDTO> products) throws ProductNotFoundException, NotEnoughQuanityException, InvalidDataProvidedException {
        checkStocks(products);

        for(ProductDTO product:products){
            updateQuantity(product,false);
        }

        return true;
    }

    private void updateQuantity(ProductDTO orderedProduct, boolean isIncrement) throws ProductNotFoundException, InvalidDataProvidedException {

        checkValidQuantityProvided(orderedProduct);
        Product originalProduct = getById(orderedProduct.getId());

        int updatedQuantity;
        if(isIncrement){
            updatedQuantity = originalProduct.getQuantity() + orderedProduct.getQuantity();
        }else {
            updatedQuantity = originalProduct.getQuantity() - orderedProduct.getQuantity();
        }

        originalProduct.setQuantity(updatedQuantity);

        inventoryRepository.save(originalProduct);
    }
    private boolean checkValidQuantityProvided(ProductDTO product) throws InvalidDataProvidedException {
        if(product.getName ()==null||product.getName ().length ()==0){
            throw new InvalidDataProvidedException ("The product name cannot take null .");
        }
        if(product.getPrice()<=0){
            throw new InvalidDataProvidedException("Price cannot take negative values");
        }

        if(product.getQuantity() <=0){
            throw new InvalidDataProvidedException("Quantity Should be Positive number");
        }
        return true;
    }

    private boolean checkValidQuantityProvided(List<ProductDTO> products) throws InvalidDataProvidedException {

        for(ProductDTO product : products){
            checkValidQuantityProvided(product);
        }

        return true;
    }

    @Override
    public Product putProduct(ProductDTO product) throws ProductNotFoundException, InvalidDataProvidedException {




        Product modifiedProduct = getById(product.getId());

        checkValidQuantityProvided(product);

        modifiedProduct.setId(product.getId());
        modifiedProduct.setName(product.getName());
        modifiedProduct.setPrice(product.getPrice());
        modifiedProduct.setImageUrl(product.getImageUrl());
        modifiedProduct.setQuantity(product.getQuantity());


        return inventoryRepository.save(modifiedProduct);
    }

    @Override
    public Product deleteProduct(int productId) throws ProductNotFoundException {
        Product result = getById(productId);
        inventoryRepository.deleteById(productId);
        return result;
    }

    @Override
    public long productCount()
    {
      return inventoryRepository.count();
    }
    @Override
    public  long minimumStockCount()
    {
        return inventoryRepository.countByQuantityLessThan (minimumStockRange);
    }

   @Override
   public List<ProductDTO> minimumStock()
    {
        List<Product> productList=inventoryRepository.findAllByQuantityLessThan (minimumStockRange);
        System.out.println (productList );
        List<ProductDTO> productDTOList=productList.stream ().map(user->modelMapper.map(user,ProductDTO.class)).collect(Collectors.toList());
        return productDTOList;
    }
    @Override
    public long outOfStockCount(){
        return inventoryRepository.countByQuantityLessThan (outOfStockRange);
    }


    @Override
    public List<ProductDTO> outOfStockProduct()
    {
        List<Product> productList=inventoryRepository.findAllByQuantityLessThan (outOfStockRange);
        System.out.println (productList );
        List<ProductDTO> productDTOList=productList.stream ().map(user->modelMapper.map(user,ProductDTO.class)).collect(Collectors.toList());
        return productDTOList;
    }
}
