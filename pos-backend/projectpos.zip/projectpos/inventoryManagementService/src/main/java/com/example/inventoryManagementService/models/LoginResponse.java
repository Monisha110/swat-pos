package com.example.inventoryManagementService.models;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class LoginResponse {
   private String userRole;
   private String userId;
}
