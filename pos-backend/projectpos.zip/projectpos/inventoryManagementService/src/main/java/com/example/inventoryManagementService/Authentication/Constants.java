package com.example.inventoryManagementService.Authentication;

public class Constants {
    public static final String INVENTORY_BASE_URL = "/inventory";

    public static final String INVENTORY_GET_BY_ID = "/id/{id}";
    public static final String INVENTORY_GET_BY_Name = "/name/{name}";
    public static final String INVENTORY_SEARCH = "/search";
    public static final String INVENTORY_GET_ALL = "/all";
    public static final String AUTH_HEADER="Authorization";
    public static final String INVENTORY_ADD = "/add";
    public static final String INVENTORY_ADD_ALL = "/add/all";

    public static final String INVENTORY_CHECK_STOCK = "/stock/";
    public static final String INVENTORY_CHECK_STOCK_ALL = "/stock/all";

    public static final String INVENTORY_INCREMENT= "/increment";
    public static final String INVENTORY_INCREMENT_ALL = "/increment/all";

    public static final String INVENTORY_REDUCE = "/reduce";
    public static final String INVENTORY_REDUCE_ALL = "/reduce/all";

    public static final String INVENTORY_UPDATE = "/update";
    public static final String INVENTORY_DELETE = "/{productId}";

    public static final String PRODUCT_COUNT="/productCount";

    public static final String MINIMUM_STOCK_COUNT="/minimumStockCount";

    public static final String MINIMUM_STOCK_PRODUCT="/minimumStockProduct";

    public static final String OUT_OF_STOCK_COUNT="/outOfStockCount";

    public static final String OUT_OF_STOCK_PRODUCT="/outOfStockProduct";

    public static final String KAFKA_TOPIC = "updateInventory";
    public static final String KAFKA_GROUP_ID = "group-1";

    public static final String USER_BASE_URL = "/user";
    public static final String USER_GET_BY_ID ="/auth/userEmail/{userEmail}" ;
    public static final String USER_LOGIN = "/login";
    public static final String USER_REGISTER = "/register";
    public static final String USER_SEARCH="/userSearch";
    public static final String USER_GET_ALL="/userAll";

    public static final String USER_UPDATE_BY_EMAIL = "/update";
    public static final String USER_REMOVE_BY_ID = "/remove/{userId}";


    public static final String SELLER_COUNT="/sellerCount";

    public static final String NAME_REGEX= "^[a-zA-Z]*$";
    public static final String MOBILE_REGEX="[0-9]+";
    public static final int MOBILE_NUMBER_LENGTH=10;
    public static final int PASSWORD_LENGTH=8;
    public static final String EMAIL_ID="[a-z0-9]+@[a-z]+.[a-z]{2,3}";


}
