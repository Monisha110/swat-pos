package com.example.orderManagementService.repository;

import com.example.orderManagementService.models.Order;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;


public interface OrderRepository extends PagingAndSortingRepository<Order,Integer> {
    public List <Order> findBySellerId(String sellerId);
}
