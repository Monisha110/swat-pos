package com.example.validation.models;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table (name="user_details",uniqueConstraints = {@UniqueConstraint(columnNames = {"userPhoneNo"})})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class User {
    private String userId;
    @Id
    private String userEmail;
    private String userName;
    private String userPassword;
    private String userPhoneNo;
    private String userRole;

}

