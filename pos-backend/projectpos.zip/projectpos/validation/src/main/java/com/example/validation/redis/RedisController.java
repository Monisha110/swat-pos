package com.example.validation.redis;


import com.example.validation.Authentication.Constants;
import com.example.validation.customExceptions.SessionExpiredException;
import com.example.validation.models.LoginResponse;
import com.example.validation.models.Tax;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@CrossOrigin("*")
@RequestMapping(Constants.REDIS)
public class RedisController {

    @Autowired
    RedisService redisService;

    @GetMapping(Constants.REDIS_GET)
    public LoginResponse getBySessionId(String sessionId) {
        try {
            return redisService.getBySessionId(sessionId);
        }
        catch (SessionExpiredException e){
            throw new ResponseStatusException(HttpStatus.GATEWAY_TIMEOUT, e.getMessage());
        } catch (JsonProcessingException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    @PostMapping(Constants.INSERT)
    public void insert(@RequestBody LoginResponse loginRequest) {
        try {
            redisService.insert(loginRequest);
        }
        catch (JsonProcessingException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }

    @GetMapping(Constants.VALIDATE_ADMIN)
    public boolean validate_admin(@RequestHeader(Constants.AUTH_HEADER) String token ){
        try {
            return redisService.validateAdmin(token);
        } catch (JsonProcessingException e) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,e.getMessage());
        }
    }

    @PostMapping(Constants.SET_TAX)
    public void setTax(@RequestBody Tax tax) {
        try {
            System.out.println(tax);
            redisService.setTax(tax);
        }
        catch (JsonProcessingException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }

    @GetMapping(Constants.GET_TAX)
    public Tax getTax(){
        try{
            Tax tax=redisService.getTax();
            return tax;
        }
        catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage());
        }
    }

}
