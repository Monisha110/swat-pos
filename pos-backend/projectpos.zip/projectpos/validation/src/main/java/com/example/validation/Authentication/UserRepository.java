package com.example.validation.Authentication;


import com.example.validation.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User,String> {
    //User findByUserNameAndUserPassword(String name,String password);
    User findByUserId(String userId);
    String deleteByUserId(String userId);
    User findByUserEmail(String userEmail);

    long countByUserRole(String userRole);

    List<User> findByUserRole(String seller);
    List<User> findAllByUserNameContainingIgnoreCase(String seller);

}
