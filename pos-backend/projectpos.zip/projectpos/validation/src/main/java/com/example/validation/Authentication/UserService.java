package com.example.validation.Authentication;

import com.example.validation.customExceptions.InvalidUserIdException;
import com.example.validation.customExceptions.InvalidUsernameOrPasswordException;
import com.example.validation.customExceptions.UserNotFoundException;
import com.example.validation.models.LoginRequest;
import com.example.validation.models.LoginResponse;
import com.example.validation.models.UserDTO;
import com.fasterxml.jackson.core.JsonProcessingException;

import javax.naming.AuthenticationException;
import java.util.List;

public interface UserService {
    LoginResponse authenticateUser(LoginRequest request) throws InvalidUsernameOrPasswordException, JsonProcessingException;
    UserDTO getUser(String userEmail) throws InvalidUserIdException, InvalidUserIdException;


    List <UserDTO> getAll(String token) throws JsonProcessingException;

    long noOfSellers();

    UserDTO postUser(UserDTO userDTO, String token) throws JsonProcessingException, AuthenticationException;

    UserDTO updateUser(UserDTO userDTO) throws UserNotFoundException;


    String deleteUser(String userId) throws UserNotFoundException;

    List<UserDTO> findAllByNameContainingIgnoreCase(String seller,String token) throws JsonProcessingException;
}
