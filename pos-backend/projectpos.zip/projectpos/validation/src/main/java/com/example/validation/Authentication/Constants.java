package com.example.validation.Authentication;

public class Constants {


    public static final String LOCALHOST="localhost";
    public static final int PORT_NUMBER=6379;
    public static final String REDIS="/redis";
    public static final String REDIS_GET="/get";
    public static final String INSERT="/insert";
    public static final String SET_TAX="/setTax";
    public static final String GET_TAX="/getTax";
    public static final String USER_BASE_URL = "/user";
    public static final String USER_GET_BY_ID ="/auth/userEmail/{userEmail}" ;
    public static final String USER_LOGIN = "/login";
    public static final String USER_REGISTER = "/register";
    public static final String USER_SEARCH="/userSearch";
    public static final String AUTH_HEADER="Authorization";
    public static final String VALIDATE_ADMIN="/validateAdmin";

    public static final String USER_UPDATE_BY_EMAIL = "/update";
    public static final String USER_REMOVE_BY_ID = "/remove/{userId}";

    public static final String USER_GET_ALL="/userAll";
    public static final String SELLER_COUNT="/sellerCount";

    public static final String NAME_REGEX= "^[a-zA-Z]*$";
    public static final String MOBILE_REGEX="[0-9]+";
    public static final int MOBILE_NUMBER_LENGTH=10;
    public static final int PASSWORD_LENGTH=8;
    public static final String EMAIL_ID="[a-z0-9]+@[a-z]+.[a-z]{2,3}";


}
