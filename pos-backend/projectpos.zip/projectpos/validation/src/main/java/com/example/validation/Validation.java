package com.example.validation;


import com.example.validation.Authentication.Constants;

public class Validation {



    public static boolean validateEmailId(String emailid){
        return emailid != null && emailid.matches(Constants.EMAIL_ID);
    }

    public static boolean validateName(String name){
        return name!=null && name.matches(Constants.NAME_REGEX);
    }

    public static boolean validateContact(String contact){

        return contact != null&&contact.matches (Constants.MOBILE_REGEX)&&
                contact.length() == Constants.MOBILE_NUMBER_LENGTH;
    }

    public static boolean regexPassword(String password){
        if(password==null)
            return false;
        if(password.length ()<8)
            return false;
        boolean flag1=false;
        boolean flag2=false;
        boolean flag3=false;
        boolean flag4=false;
        for(int i=0;i<password.length ();i++){
            if(password.charAt (i)>='a'&&password.charAt (i)<='z')
                flag1=true;
            else if(password.charAt (i)>='A'&&password.charAt (i)<='Z')
                flag2=true;
            else if(password.charAt (i)>='0'&&password.charAt (i)<='9')
                flag3=true;
            else if(password.charAt (i)=='#'||password.charAt (i)=='-'||password.charAt (i)=='+'||password.charAt (i)=='_'||password.charAt (i)=='!'||password.charAt (i)=='@'||password.charAt (i)=='$'||password.charAt (i)=='%'||password.charAt (i)=='^'||password.charAt (i)=='&'||password.charAt (i)=='*'||password.charAt (i)=='.'||password.charAt (i)==','||password.charAt (i)=='?')
                flag4=true;
        }
        System.out.println (flag1+" "+flag2+" "+flag3+" "+flag4 );
        return flag1&&flag2&&flag3&&flag4;
    }
    public static boolean validatePassword( String password ){

        return password!=null && password.length() >= Constants.PASSWORD_LENGTH && regexPassword(password);
    }

   /* public static boolean validatePrice(float price)
    {
        return price>0;
    }

    public static boolean validateQuantity(int quantity)
    {
        return quantity>0;
    }*/

    public static String returnStatusMessage(boolean status){
        return status? "User Added": "Can't add User..Check the details..";
    }


}
