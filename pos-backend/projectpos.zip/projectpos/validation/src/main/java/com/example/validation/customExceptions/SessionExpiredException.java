package com.example.validation.customExceptions;

public class SessionExpiredException extends Exception{
    public SessionExpiredException(String str){
        super(str);
    }
}
