package com.example.validation.models;

import lombok.Data;

@Data
public class UserDTO {
    private String userId;
    private String userName;
    private String userEmail;
    private String userPassword;
    private String userPhoneNo;
    private String userRole;

}
