package com.example.validation.redis;

import com.example.validation.customExceptions.SessionExpiredException;
import com.example.validation.models.LoginResponse;
import com.example.validation.models.Tax;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface RedisService {

    String objectSerializer(LoginResponse loginResponse) throws JsonProcessingException;

    LoginResponse objectDeserializer(String str) throws JsonProcessingException;

    LoginResponse getBySessionId(String sessionId) throws JsonProcessingException, SessionExpiredException;

    boolean validateAdmin(String sessionId) throws JsonProcessingException;

    void insert(LoginResponse loginResponse) throws JsonProcessingException;

    void setTax(Tax tax) throws JsonProcessingException;

    Tax getTax();
}
