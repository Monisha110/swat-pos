package com.example.validation.models;

import lombok.Data;

@Data
public class Tax {
    private float cgst;
    private float sgst;
}
