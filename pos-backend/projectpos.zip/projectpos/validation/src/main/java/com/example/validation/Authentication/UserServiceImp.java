package com.example.validation.Authentication;


import com.example.validation.Validation;
import com.example.validation.customExceptions.InvalidUsernameOrPasswordException;
import com.example.validation.models.*;
import com.example.validation.customExceptions.*;
import com.example.validation.redis.RedisService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.naming.AuthenticationException;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Transactional
@Service
public class UserServiceImp implements UserService {

    @Autowired
    RedisService redisService;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    UserRepository userRepository;

    @Override
    public LoginResponse authenticateUser(LoginRequest request) throws InvalidUsernameOrPasswordException, JsonProcessingException {

        User user = userRepository.findByUserEmail(request.getUserEmail ( ));
        LoginResponse response=new LoginResponse ();
        if (user!=null &&user.getUserPassword ().matches(request.getUserPassword ( ))){
            response.setSessionId(UUID.randomUUID().toString());
            response.setUserId (user.getUserId());
            response.setUserRole(user.getUserRole ());
            redisService.insert(response);
            return response;
        }
        throw new InvalidUsernameOrPasswordException("Invalid Username Or Password");
    }

    @Override
    public UserDTO getUser(String userEmail) throws InvalidUserIdException {
        User result= userRepository.findByUserEmail(userEmail);
        if(result==null){
            throw new InvalidUserIdException("Invalid User Id");
        }
        return modelMapper.map(result,UserDTO.class);
    }

    @Override
    public UserDTO postUser(UserDTO userDTO, String token) throws JsonProcessingException, AuthenticationException {
        if(redisService.validateAdmin(token)) {
            User user = modelMapper.map(userDTO, User.class);
            if (userRepository.findByUserEmail(user.getUserEmail()) == null) {
                System.out.println(user.getUserEmail());
                if (!Validation.validateEmailId(user.getUserEmail()))
                    throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE, "Check whether the email is Correct");
                if (!Validation.validateName(user.getUserName()))
                    throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE, "Check whether name is Correct");
                if (!Validation.validatePassword(user.getUserPassword()))
                    throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE, "Check whether password is Correct");
                if (!Validation.validateContact(user.getUserPhoneNo()))
                    throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE, "Check whether contact is Correct");
                user.setUserId(UUID.randomUUID().toString());
                user.setUserRole("Seller");
                userRepository.save(user);
            } else {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Seller Already Exists");
            }
            return modelMapper.map(user, UserDTO.class);
        }
        else{
            throw new AuthenticationException("Your are not authorized to proceed");
        }
    }

    @Override
    public UserDTO updateUser(UserDTO userDTO) throws UserNotFoundException {
        User user=modelMapper.map(userDTO,User.class);
        user.setUserRole ("Seller");
        if(userRepository.findByUserEmail (user.getUserEmail ())!=null) {
            userRepository.save (user);
        }
        else
        {
            throw new UserNotFoundException ("USER NOT FOUND");
        }
        return modelMapper.map(user,UserDTO.class);
    }


    @Override
    public String deleteUser(String userId)throws UserNotFoundException
    {
        if(userRepository.findByUserId (userId)!=null) {
            userRepository.deleteByUserId (userId);
        }
        else {
            throw new UserNotFoundException ("USER NOT FOUND");
        }
        return "Deleted Successfully";
    }
    @Override
    public List <UserDTO> getAll(String token) throws JsonProcessingException {
        if(!redisService.validateAdmin(token))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"You are not authorized");
        List<User>userList=userRepository.findByUserRole("Seller");
        List<UserDTO> userDTOList=userList.stream ().map(user->modelMapper.map(user,UserDTO.class)).collect(Collectors.toList());
        return userDTOList;
    }
    @Override
    public  long noOfSellers()
    {
        return userRepository.countByUserRole ("Seller");
    }
    @Override
    public List<UserDTO> findAllByNameContainingIgnoreCase(String sellerName,String token) throws JsonProcessingException {
        if(!redisService.validateAdmin(token))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"You are not authorized");
        List<User>users= userRepository.findAllByUserNameContainingIgnoreCase(sellerName);
        List<UserDTO>seller=new ArrayList<>();
        for(int i=0;i<users.size();i++){
            if(users.get(i).getUserRole().equals("Seller")){
                seller.add(modelMapper.map(users.get(i),UserDTO.class));
            }
        }
        return seller;
    }
}
