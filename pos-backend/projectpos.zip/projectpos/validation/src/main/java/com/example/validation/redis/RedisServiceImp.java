package com.example.validation.redis;

import com.example.validation.customExceptions.SessionExpiredException;
import com.example.validation.models.LoginResponse;
import com.example.validation.models.Tax;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class RedisServiceImp implements RedisService {

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    RedisTemplate redisTemplate;


    @Override
    public String objectSerializer(LoginResponse loginResponse) throws JsonProcessingException {
        return objectMapper.writeValueAsString(loginResponse);
    }

    @Override
    public LoginResponse objectDeserializer(String str) throws JsonProcessingException {
        return objectMapper.readValue(str, LoginResponse.class);
    }

    @Override
    public LoginResponse getBySessionId(String sessionId) throws JsonProcessingException, SessionExpiredException {
        String response=String.valueOf(redisTemplate.opsForHash().get("tokens",sessionId));
        if(response==null){
            throw new SessionExpiredException("The session has expired please login.");
        }
        return objectDeserializer(response);
    }

    @Override
    public boolean validateAdmin(String sessionId) throws JsonProcessingException {
        LoginResponse loginResponse=objectDeserializer((String) redisTemplate.opsForHash().get("tokens",sessionId));
        if(loginResponse.getUserRole().equals("Admin")){
            return true;
        }
        else
            return false;
    }

    @Override
    public void insert(LoginResponse loginResponse) throws JsonProcessingException {
        System.out.println("insert"+loginResponse);
        redisTemplate.opsForHash().put("tokens",loginResponse.getSessionId(),objectMapper.writeValueAsString(loginResponse));
        redisTemplate.expire(loginResponse.getSessionId(),600000, TimeUnit.SECONDS);
    }

    @Override
    public void setTax(Tax tax) throws JsonProcessingException {
        redisTemplate.opsForHash().put("tax","CGST",objectMapper.writeValueAsString(tax.getCgst()));
        redisTemplate.opsForHash().put("tax","SGST",objectMapper.writeValueAsString(tax.getSgst()));
    }
    @Override
    public Tax getTax(){
        Tax tax=new Tax();
        tax.setCgst(Float.valueOf(String.valueOf(redisTemplate.opsForHash().get("tax","CGST"))));
        tax.setSgst(Float.valueOf(String.valueOf(redisTemplate.opsForHash().get("tax","SGST"))));
        return tax;
    }

}
