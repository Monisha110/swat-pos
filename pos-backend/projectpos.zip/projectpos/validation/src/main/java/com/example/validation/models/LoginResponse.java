package com.example.validation.models;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class LoginResponse {
   private String SessionId;
   private String userRole;
   private String userId;
}
