package com.example.validation.Authentication;


import com.example.validation.models.*;
import com.example.validation.models.LoginResponse;
import com.example.validation.models.User;
import com.example.validation.models.UserDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import sun.security.util.SecurityConstants;

import javax.naming.AuthenticationException;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(Constants.USER_BASE_URL)
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping(Constants.USER_LOGIN)
    public LoginResponse getUser(@RequestBody LoginRequest request){
        try {
            return userService.authenticateUser(request);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }

    @PostMapping(Constants.USER_REGISTER)
    public UserDTO addUser(@RequestBody UserDTO userDTO,@RequestHeader(Constants.AUTH_HEADER) String token ){
        try {
            System.out.println(userDTO+" "+token);
            return userService.postUser(userDTO,token);
        }
        catch (AuthenticationException e){
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,e.getMessage());
        }
        catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    @GetMapping(Constants.USER_GET_BY_ID)
    public UserDTO getUser(@PathVariable String userEmail){
        try {
            return userService.getUser(userEmail);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }

    @PutMapping(Constants.USER_UPDATE_BY_EMAIL)
    public UserDTO updateUser(@RequestBody UserDTO userDTO)
    {
        try {
            return userService.updateUser(userDTO);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    @DeleteMapping(Constants.USER_REMOVE_BY_ID)
    public String deleteUser(@PathVariable String userId)
    {
        try {
            return userService.deleteUser(userId);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    @GetMapping(Constants.SELLER_COUNT)
    public long sellerCount()
    {
        return userService.noOfSellers ();
    }

    @GetMapping(Constants.USER_GET_ALL)
    public List <UserDTO> getAll(@RequestHeader(Constants.AUTH_HEADER) String token ) throws JsonProcessingException {
        try {
            return userService.getAll (token);
        } catch (JsonProcessingException e) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,"You are not authorized");
        }
    }

    @GetMapping(Constants.USER_SEARCH)
    public List<UserDTO>searchProductsByName(@RequestParam String seller,@RequestHeader(Constants.AUTH_HEADER) String token ){
        try {
            return userService.findAllByNameContainingIgnoreCase(seller,token);
        } catch (JsonProcessingException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Json Processing Exception");
        }
    }

}
