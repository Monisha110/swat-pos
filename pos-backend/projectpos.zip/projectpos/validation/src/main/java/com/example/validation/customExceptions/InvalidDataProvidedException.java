package com.example.validation.customExceptions;

public class InvalidDataProvidedException extends Exception {
    public InvalidDataProvidedException(String message) {
        super(message);
    }
}
