package com.example.validation.customExceptions;

public class AuthenticationException extends Exception{
    public AuthenticationException(String str){
        super(str);
    }
}
