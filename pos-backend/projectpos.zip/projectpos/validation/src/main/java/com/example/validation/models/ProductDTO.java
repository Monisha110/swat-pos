package com.example.validation.models;

import lombok.Data;

@Data
public class ProductDTO {
    private int id;
    private String name;
    private String description;
    private float price;
    private String imageUrl;
    private int quantity;
}
